# Aroma + Bachblüten – Android v1.12.1

Dieses Projekt verpackt die HTML-Version `1.12.1 STABLE FROZEN` in eine Android WebView. Die HTML-Datei ist unter `app/src/main/assets/index.html` eingebettet. Die App benötigt für die eingebetteten Inhalte keine Netzwerkberechtigung.

## APK bauen
1. Android Studio (mit Android SDK 35 und JDK 17) installieren.
2. **Open** → diesen Projektordner auswählen. Gradle-Synchronisierung abwarten (Internet für Build-Abhängigkeiten erforderlich).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug-APK: `app/build/outputs/apk/debug/app-debug.apk`.
5. Für eine weitergebbare Release-APK: **Build → Generate Signed Bundle / APK** und einen eigenen Keystore anlegen.

## Hinweise
- Druck/PDF: Android-Druckdialog verwenden und **Als PDF speichern** auswählen.
- Favoriten/Journey, soweit im HTML mit `localStorage` gespeichert, verbleiben lokal in den App-Daten. Eine Deinstallation löscht sie normalerweise.
- Keine Android-APK wurde in dieser Umgebung kompiliert oder auf einem Gerät getestet.
- Offline-Funktionen setzen voraus, dass die HTML-App keine externen Ressourcen benötigt.
- Paketname `de.aromabachblueten.app` und App-Name können angepasst werden.
