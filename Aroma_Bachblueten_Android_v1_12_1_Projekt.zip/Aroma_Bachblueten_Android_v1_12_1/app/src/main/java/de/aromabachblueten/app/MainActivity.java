package de.aromabachblueten.app;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(35,65,52));
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new PrintBridge(), "AndroidPrint");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private class PrintBridge {
        @JavascriptInterface public void printRecipe() { runOnUiThread(() -> {
            PrintManager manager = (PrintManager)getSystemService(Context.PRINT_SERVICE);
            manager.print("Aroma-Rezept", web.createPrintDocumentAdapter("Aroma-Rezept"), new PrintAttributes.Builder().build());
        }); }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var m=document.querySelector('#mixtureRecipeModal');if(m && (m.classList.contains('open') || getComputedStyle(m).display !== 'none')){var c=m.querySelector('[data-close],.recipe-close');if(c){c.click();return 'closed';}}return 'none';})()", result -> {
            if (!"\"closed\"".equals(result)) {
                if(web.canGoBack()) web.goBack(); else MainActivity.super.onBackPressed();
            }
        });
    }
    @Override protected void onDestroy(){ web.destroy(); super.onDestroy(); }
}
